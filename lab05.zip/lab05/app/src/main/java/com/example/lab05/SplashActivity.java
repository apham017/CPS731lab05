package com.example.lab05;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Handler;

import android.content.Intent;
import android.os.Bundle;

import com.example.lab05.dummy.DummyContent;


public class SplashActivity extends AppCompatActivity {
    private static int splashtime = 5000;
    MediaPlayer music;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        music = MediaPlayer.create(getApplicationContext(), R.raw.freeze);
        music.start();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent Intent1 = new Intent(SplashActivity.this, ItemListActivity.class);
                startActivity(Intent1);
                finish();
            }
        }, splashtime);
    }

    @Override
    protected void onPause() {
        super.onPause();
        music.release();
        finish();
    }

}