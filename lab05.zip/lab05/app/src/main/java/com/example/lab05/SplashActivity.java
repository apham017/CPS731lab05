package com.example.lab05;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;

import android.content.Intent;
import android.os.Bundle;

import com.example.lab05.dummy.DummyContent;


public class SplashActivity extends AppCompatActivity {
    private static int splashtime = 5000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run(){
                Intent Intent1 = new Intent(SplashActivity.this, ItemListActivity.class);
                startActivity(Intent1);
                finish();
            }
        }, splashtime);

    }
}